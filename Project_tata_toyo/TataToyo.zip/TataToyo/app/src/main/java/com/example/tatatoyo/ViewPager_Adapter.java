package com.example.tatatoyo;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

class ViewPager_Adapter extends FragmentStatePagerAdapter {

    public ViewPager_Adapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                return new com.example.tatatoyo.RedeemFragment();

            case 1:
                return  new com.example.tatatoyo.HomeFragment();

//            case 2:
//                return  new ScanFragment();

        }

        return new com.example.tatatoyo.HomeFragment();
    }

    @Override
    public int getCount() {
        return 2;
    }
}
