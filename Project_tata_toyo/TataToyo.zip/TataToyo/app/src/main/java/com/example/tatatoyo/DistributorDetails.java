package com.example.tatatoyo;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Transaction;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.StringTokenizer;

public class DistributorDetails extends AppCompatActivity {

    private EditText distributorName, distributorDetails;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String Userid;
    private Map<String, String> scan = new HashMap<String, String>();
    private long mLastClickTime = 0;
    private int temp , points;
    private String litres, id, points_in_bag, total, po;
    private StringTokenizer box;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distributor_details);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // Instantiating the text
        distributorName = findViewById(R.id.distributorName);
        distributorDetails = findViewById(R.id.cityName);

        // creating firestore instances
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        FirebaseUser Firebase_User = mAuth.getCurrentUser();
        if (Firebase_User != null) {
            Userid = Firebase_User.getUid();
        }

        //getting the scanner id and checked
        Intent i = getIntent();
        id = i.getStringExtra("ID");
        points_in_bag = i.getStringExtra("PT");


        // checking if box is already scanned
        alreadyScanned(id);

        //getting the box
        box = new StringTokenizer(id, "$");
        litres = box.nextToken();

        //writing functionality of button
        Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // button click handling
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();


                //getting and checking if details are entered
                final String name = distributorName.getText().toString().trim(), city = distributorDetails.getText().toString().trim();
                if(checkName(name, distributorName) && checkName(city, distributorDetails)){
                    //map for storing details

                    int point = changeHomeScreenPoints(litres);
                    String litre_alphabet;
                    if(litres.equals("25") || litres.equals("21") || litres.equals("13"))
                        litre_alphabet = ("L"+litres).toLowerCase();
                    else
                        litre_alphabet = litres.toLowerCase();
                    // storing the details
                    storeDetails(name + "$" + city, scan, point, litre_alphabet);
                }
            }
        });
    }

    // check
    private void alreadyScanned(String id){
        db.collection("Scanner").document("12").get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                        scan = (HashMap<String, String>) documentSnapshot.get("Scan");
                        if(scan != null && scan.containsKey(id)){
                            Toast.makeText(com.example.tatatoyo.DistributorDetails.this, "Already scanned", Toast.LENGTH_LONG).show();
                            finish();
                        }else if(scan != null){
                            scan.put(id, "");
                        }
                    }
                });
    }

    //storing distributor details in dB
    private void storeDetails(String city, Map scan, int point, String litre_alphabet){

        final DocumentReference usersDocRef = db.collection("Users").document(Userid);
        final DocumentReference scannerDocRef = db.collection("Scanner").document("12");
        db.runTransaction(new Transaction.Function<Void>() {
            @Nullable
            @Override
            public Void apply(@NonNull Transaction transaction) throws FirebaseFirestoreException {
                DocumentSnapshot userSnapshot = transaction.get(usersDocRef);

                // points increment
                int pt = Integer.parseInt(Objects.requireNonNull(userSnapshot.getString(litre_alphabet)));
                pt = pt + 1;
                po = Integer.toString(pt);

                //getting total points
                total = Integer.toString(point);

                //getting the map
                Map<String, String> d = (Map<String, String>) userSnapshot.get("distributors");
                if(d != null && city != null && !d.containsKey(city)){
                    d.put(city, " ");
                }


                transaction.update(usersDocRef, "distributors", d);
                transaction.update(scannerDocRef, "Scan", scan);
                transaction.update(usersDocRef, litre_alphabet, po);
                transaction.update(usersDocRef, "points", total);
                //Success
                return null;
            }
        }).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                com.example.tatatoyo.HomeFragment.textView.setText(total);
                setCount(litres);
                Toast.makeText(com.example.tatatoyo.DistributorDetails.this, "Congratulations! You have been awarded ‘"+ (points - temp) +"’ Reward Points against your order of\n" +
                        "‘"+ litre_alphabet +" – Coolant 1 Carton‘.", Toast.LENGTH_LONG).show();
                finish();
            }
        })
        .addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(com.example.tatatoyo.DistributorDetails.this, "Unable to process your request (Check your Internet connectivity).", Toast.LENGTH_LONG).show();
            }
        });
    }

    // check name
    private boolean checkName(String Name, EditText Shop_Name){
        if (Name.isEmpty()) {
            Shop_Name.setError("Field is required");
            Shop_Name.requestFocus();
            return false;
        }
        return true;
    }


    //changing home screen points
    private int changeHomeScreenPoints(String box){
        points = Integer.parseInt(points_in_bag);
        temp = points;
        switch (box){
            case "L1":
            case "L3":
                points = points + 160;
                break;
            case "L5":
                points = points + 150;
                break;
            case "13":
                points = points + 120;
                break;
            case "21":
                points = points + 1300;
                break;
            case "25":
                points = points + 175;
                break;
            default:
                return 0;
        }
        return points;
    }

    private void setCount(String box){
        switch (box){
            case "L1":
                com.example.tatatoyo.HomeFragment.L1.setText(po);
                break;
            case "L3":
                com.example.tatatoyo.HomeFragment.L3.setText(po);
                break;
            case "L5":
                com.example.tatatoyo.HomeFragment.L5.setText(po);
                break;
            case "13":
                com.example.tatatoyo.HomeFragment.L13.setText(po);
                break;
            case "21":
                com.example.tatatoyo.HomeFragment.L210.setText(po);
                break;
            case "25":
                com.example.tatatoyo.HomeFragment.L25.setText(po);
                break;
        }
    }
}