package com.example.tatatoyo;

import android.content.DialogInterface;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Transaction;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class Rewards extends AppCompatActivity implements  View.OnClickListener{

    private CardView waterBottle  , dinnerset , androidTv ,foldableBakPack ,bluetoothSpeaker ,bowlset ,zaraPlatina , canadaTrip ,iron ,gold ,passionbike,lenovolaptop,samsungm31,samsungnote10,myntraVoucher,nikevoucher,burner,pigeonCooker,powerBank,riccaMugSet,sipperwB,lenovoTab,tablefan,tanishqVoucher,tanishqVoucherCostly,tanishqVoucherMoreCostly,trolleybag,wiredEarphones,wirelessbluetooh,wrielesdskeyboiard;
    private int mPoint, mCurrentPoints;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String Userid, mRewardName;
    private  long mLastClickTime = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rewards);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        mCurrentPoints = Integer.parseInt(com.example.tatatoyo.HomeFragment.textView.getText().toString());

        // creating firestore instances
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        FirebaseUser Firebase_User = mAuth.getCurrentUser();
        if (Firebase_User != null) {
            Userid = Firebase_User.getUid();
        }

        //instantiating card view
        waterBottle = findViewById(R.id.waterBottle);
        wiredEarphones = findViewById(R.id.wiredEarphones);
        riccaMugSet = findViewById(R.id.riccaMugSet);
        sipperwB = findViewById(R.id.sipperwB);
        foldableBakPack = findViewById(R.id.foldableBakPack);
        bowlset = findViewById(R.id.bowlset);
        bluetoothSpeaker = findViewById(R.id.bluetoothSpeaker);
        zaraPlatina = findViewById(R.id.zaraPlatina);
        iron = findViewById(R.id.iron);
        wrielesdskeyboiard = findViewById(R.id.wrielesdskeyboiard);
        wirelessbluetooh = findViewById(R.id.wirelessbluetooh);
        powerBank = findViewById(R.id.powerBank);
        pigeonCooker = findViewById(R.id.pigeonCooker);
        dinnerset = findViewById(R.id.dinnerset);
        tablefan = findViewById(R.id.tablefan);
        trolleybag = findViewById(R.id.trolleybag);
        burner = findViewById(R.id.burner);
        nikevoucher = findViewById(R.id.nikevoucher);
        gold = findViewById(R.id.gold);
        lenovoTab = findViewById(R.id.lenovoTab);
        myntraVoucher = findViewById(R.id.myntraVoucher);
        androidTv = findViewById(R.id.androidTv);
        samsungm31 = findViewById(R.id.samsungm31);
        lenovolaptop = findViewById(R.id.lenovolaptop);
        tanishqVoucher = findViewById(R.id.tanishqVoucher);
        samsungnote10 = findViewById(R.id.samsungnote10);
        tanishqVoucherCostly = findViewById(R.id.tanishqVoucherCostly);
        canadaTrip = findViewById(R.id.canadaTrip);
        passionbike = findViewById(R.id.passionbike);
        tanishqVoucherMoreCostly = findViewById(R.id.tanishqVoucherMoreCostly);


        //clicks
        waterBottle.setOnClickListener(this);
        wiredEarphones.setOnClickListener(this);
        dinnerset.setOnClickListener(this);
        androidTv.setOnClickListener(this);
        foldableBakPack.setOnClickListener(this);
        bluetoothSpeaker.setOnClickListener(this);
        bowlset.setOnClickListener(this);
        zaraPlatina.setOnClickListener(this);
        canadaTrip.setOnClickListener(this);
        iron.setOnClickListener(this);
        gold.setOnClickListener(this);
        passionbike.setOnClickListener(this);
        lenovolaptop.setOnClickListener(this);
        lenovoTab.setOnClickListener(this);
        samsungm31.setOnClickListener(this);
        samsungnote10.setOnClickListener(this);
        myntraVoucher.setOnClickListener(this);
        nikevoucher.setOnClickListener(this);
        pigeonCooker.setOnClickListener(this);
        burner.setOnClickListener(this);
        powerBank.setOnClickListener(this);
        riccaMugSet.setOnClickListener(this);
        sipperwB.setOnClickListener(this);
        tablefan.setOnClickListener(this);
        tanishqVoucher.setOnClickListener(this);
        tanishqVoucherCostly.setOnClickListener(this);
        tanishqVoucherMoreCostly.setOnClickListener(this);
        trolleybag.setOnClickListener(this);
        wirelessbluetooh.setOnClickListener(this);
        wrielesdskeyboiard.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {

        if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
            return;
        }
        mLastClickTime = SystemClock.elapsedRealtime();

        switch (view.getId()){
            case R.id.waterBottle :
                mPoint = 750;
                showDialog();
                mRewardName = "Steel Water Bottle (800ml)";
                break;
            case R.id.wiredEarphones:
                mPoint = 750;
                showDialog();
                mRewardName = "Wired Earphone";
                break;
            case R.id.riccaMugSet:
                mPoint = 750;
                showDialog();
                mRewardName = "Ricca Mug Set (6-pcs)";
                break;
            case R.id.sipperwB:
                mPoint = 1000;
                showDialog();
                mRewardName = "Sipper Water Bottle (400ml)";
                break;
            case R.id.foldableBakPack:
                mPoint = 1000;
                showDialog();
                mRewardName ="Foldable BackPack";
                break;
            case R.id.bowlset:
                mPoint = 1000;
                showDialog();
                mRewardName = "Bowlset (6-pcs)";
                break;
            case R.id.bluetoothSpeaker:
                mPoint = 2000;
                showDialog();
                mRewardName = "Bluetooth Speaker";
                break;
            case R.id.zaraPlatina:
                mPoint = 2000;
                showDialog();
                mRewardName = "Zara Platini Nexus Coffee Set (1 Flask + 6 Cups)";
                break;
            case R.id.iron:
                mPoint = 2000;
                showDialog();
                mRewardName = "Iron (Pigeon)";
                break;
            case R.id.wrielesdskeyboiard:
                mPoint = 3000;
                showDialog();
                mRewardName = "Portronics-Wireless Keyboard and Mouse";
                break;
            case R.id.wirelessbluetooh:
                mPoint = 3000;
                showDialog();
                mRewardName = "Wireless Bluetooth Headset";
                break;
            case R.id.powerBank:
                mPoint = 3000;
                showDialog();
                mRewardName = "Power Bank (10000 mAh)";
                break;
            case R.id.pigeonCooker:
                mPoint = 5000;
                showDialog();
                mRewardName = "Pigeon Induction Cooker";
                break;
            case R.id.dinnerset:
                mPoint = 5000;
                showDialog();
                mRewardName = "Dazzle 24 Pcs Dinner Set";
                break;
            case R.id.tablefan:
                mPoint = 5000;
                showDialog();
                mRewardName = "Table Fan";
                break;
            case R.id.trolleybag:
                mPoint = 10000;
                showDialog();
                mRewardName = "Trolley Bag";
                break;
            case R.id.burner:
                mPoint = 10000;
                showDialog();
                mRewardName = "Pigeon 4 Stove Burner";
                break;
            case R.id.nikevoucher:
                mPoint = 10000;
                showDialog();
                mRewardName = "Nike Gift Voucher (worth Rs. 4000)";
                break;
            case R.id.gold:
                mPoint = 25000;
                showDialog();
                mRewardName = "Gold Coin (worth Rs. 8000)";
                break;
            case R.id.lenovoTab:
                mPoint = 25000;
                showDialog();
                mRewardName = "Lenovo E8 Tab";
                break;
            case R.id.myntraVoucher:
                mPoint = 25000;
                showDialog();
                mRewardName = "Myntra Voucher (Worth Rs. 8500)";
                break;
            case R.id.androidTv:
                mPoint = 50000;
                showDialog();
                mRewardName = "Android TV";
                break;
            case R.id.samsungm31:
                mPoint = 50000;
                showDialog();
                mRewardName = "Samsung Galaxy M31";
                break;
            case R.id.tanishqVoucher:
                mPoint = 50000;
                showDialog();
                mRewardName = "Tanishq Voucher (worth Rs. 16000)";
                break;
            case R.id.lenovolaptop:
                mPoint = 125000;
                showDialog();
                mRewardName = "Lenovo Laptop - IdeaPad 3";
                break;
            case R.id.samsungnote10:
                mPoint = 125000;
                showDialog();
                mRewardName = "Samsung Galaxy Note 10 Lite";
                break;
            case R.id.tanishqVoucherCostly:
                mPoint = 125000;
                showDialog();
                mRewardName = "Tanishq Voucher (worth Rs. 33000)";
                break;
            case R.id.canadaTrip:
                mPoint = 250000;
                showDialog();
                mRewardName = "Foreign Trip";
                break;
            case R.id.passionbike:
                mPoint = 250000;
                showDialog();
                mRewardName = "Hero Passion Pro Bike";
                break;
            case R.id.tanishqVoucherMoreCostly:
                mPoint = 250000;
                showDialog();
                mRewardName = "Tanishq Voucher worth Rs. 65000";
                break;
            default:
                break;
        }
    }


    //dailog after clicking on prize and handelled points decrement too.
    private void showDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(this));
        builder.setMessage("Please Note:\n1) Pictures are displayed are only for visual brief and product may not be exactly the same as in picture.\n" +
                "2) In case of any product quality issue, replacement would be provided with the condition of\n" +
                "15 days from the date of Receipt.\n" +
                "3) In case of any dispute, decision of TATA TOYO will be Final.")
                .setCancelable(false)
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // if user clicks yes and he has points
                        if(isPossible(mPoint)){
                            mCurrentPoints = mCurrentPoints - mPoint;
                            storeDetails();
                        }else{
                            Toast.makeText(com.example.tatatoyo.Rewards.this, "Insufficient points", Toast.LENGTH_LONG).show();
                        }
                    }
                })
                .setNegativeButton("NO", null);
        AlertDialog alert = builder.create();
        alert.show();
    }

    private boolean isPossible(long points){
        if(points > mCurrentPoints){
            return false;
        }
        return true;
    }

    //storing distributor details in dB
    private void storeDetails(){

        final DocumentReference usersDocRef = db.collection("Users").document(Userid);
        final CollectionReference rewardsDocRef = db.collection("Users").document(Userid).collection("Rewards");

        db.runTransaction(new Transaction.Function<Void>() {
            @Nullable
            @Override
            public Void apply(@NonNull Transaction transaction) throws FirebaseFirestoreException {
                DocumentSnapshot userSnapshot = transaction.get(usersDocRef);

                // getting all the fields needed to store in collection
                Map<String , String> map = new HashMap<>();

                String owner_name = (String) userSnapshot.get("owner_name");
                String city = (String) userSnapshot.get("city");
                String mobile_no = (String) userSnapshot.get("mobile_number");
                String shop_address = (String) userSnapshot.get("shop_address");
                String shop_name = (String) userSnapshot.get("shop_name");
                String state = (String) userSnapshot.get("state");
                String pin_code = (String) userSnapshot.get("pincode");

                Calendar calendar = Calendar.getInstance();
                Boolean flag = false;

                // created a map

                map.put("owner_name", owner_name);
                map.put("city", city);
                map.put("mobile_no", mobile_no);
                map.put("shop_address", shop_address);
                map.put("shop_name", shop_name);
                map.put("state", state);
                map.put("pin_code", pin_code);
                map.put("reward", mRewardName);
                map.put("messageTime", String.valueOf(calendar.getTime()));
                map.put("is_complete" , String.valueOf(flag));


                rewardsDocRef.add(map);
                transaction.update(usersDocRef, "points",Integer.toString(mCurrentPoints));
                return null;
            }
        }).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                com.example.tatatoyo.HomeFragment.textView.setText(Integer.toString(mCurrentPoints));
                Toast.makeText(com.example.tatatoyo.Rewards.this, "Congrats !!.. We will reach out to you shortly.", Toast.LENGTH_LONG).show();
                finish();
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(com.example.tatatoyo.Rewards.this, "Unable to process your request (Check your Internet connectivity).", Toast.LENGTH_LONG).show();
                    }
                });
    }


//    // reward dialog
//    private void RewardDialog(){
//        AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(this));
//        builder.setMessage("Please Note:\n1) Pictures are displayed are only for visual brief and product may not be exactly the same as in picture.\n" +
//                "2) In case of any product quality issue, replacement would be provided with the condition of\n" +
//                "15 days from the date of Receipt.\n" +
//                "3) In case of any dispute, decision of TATA TOYO will be Final.")
//                .setCancelable(false)
//                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        // if user clicks yes and he has points
//                        if(isPossible(mPoint)){
//                            mCurrentPoints = mCurrentPoints - mPoint;
//                            storeDetails();
//                        }else{
//                            Toast.makeText(Rewards.this, "Insufficient points", Toast.LENGTH_LONG).show();
//                        }
//                    }
//                })
//                .setNegativeButton("NO", null);
//        AlertDialog alert = builder.create();
//        alert.show();
//    }
}