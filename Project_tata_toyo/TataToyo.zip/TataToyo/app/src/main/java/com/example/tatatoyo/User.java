package com.example.tatatoyo;

import java.util.HashMap;
import java.util.Map;

public class User {

    private String Shop_name;
    private String Owner_name;
    private String Shop_address;
    private String City;
    private String Pincode;
    private String State;
    private String mobile_number;
    private String Points;
    private String L1;
    private String L3;
    private String L5;
    private String L25;
    private String L21;
    private String L13;
    private Map<String,String> Distributors = new HashMap<String , String>();

    public Map<String, String> getDistributors() {
        return Distributors;
    }

    public void setDistributors(Map<String, String> distributors) {
        Distributors = distributors;
    }

    public void setL1(String L1) {
        this.L1 = L1;
    }

    public String getL3() {
        return L3;
    }

    public void setL3(String L3) {
        this.L3 = L3;
    }

    public String getL5() {
        return L5;
    }

    public void setL5(String L5) {
        this.L5 = L5;
    }

    public String getL25() {
        return L25;
    }

    public void setL25(String l25) {
        this.L25 = L25;
    }

    public String getL21() {
        return L21;
    }

    public void setL21(String L21) {
        this.L21 = L21;
    }

    public String getL13() {
        return L13;
    }

    public void setL13(String L13) {
        this.L13 = L13;
    }

    public String getCity() {
        return City;
    }

    public String getOwner_name() {
        return Owner_name;
    }

    public String getPincode() {
        return Pincode;
    }

    public String getShop_address() {
        return Shop_address;
    }

    public String getShop_name() {
        return Shop_name;
    }

    public String getState() {
        return State;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public String getPoints() {
        return Points;
    }

    public void setPoints(String points) {
        Points = points;
    }

    public String getL1() {
        return L1;
    }


    public User()
    {

    }
    public User(String shop , String owner , String shop_address , String city , String pin , String state , String mobile_number)
    {
        this.Shop_name = shop;
        this.Owner_name = owner;
        this.Shop_address = shop_address;
        this.City = city;
        this.Pincode = pin;
        this.State = state;
        this.mobile_number = mobile_number;
        this.Points = "100";
        this.L1 = "0";
        this.L13 = "0";
        this.L3 = "0";
        this.L5 = "0";
        this.L25 = "0";
        this.L21 = "0";
        this.L13 = "0";
        this.Distributors.put("null" ,"null");
    }
}
