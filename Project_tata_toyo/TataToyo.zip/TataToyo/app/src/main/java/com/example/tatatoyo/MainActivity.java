package com.example.tatatoyo;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore db;

    private long mLastClickTime = 0;
    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        // check for internet connection
        if(!haveNetworkConnection())
        {
            showDialog();
            return;
        }
        mAuth = FirebaseAuth.getInstance();
        db=FirebaseFirestore.getInstance();

        if(mAuth.getCurrentUser() != null)

        {
            isUserRegistered();
            startActivity(new Intent(com.example.tatatoyo.MainActivity.this , BottomNav.class));
            finish();
        }
        // gathering things
        final EditText inputMobile = findViewById(R.id.editTextTextPersonPhoneNumber);
        Button button = findViewById(R.id.button);

        //on click
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                // If it's empty
                if (inputMobile.getText().toString().trim().isEmpty() || inputMobile.getText().toString().length() < 10 || inputMobile.getText().toString().length() >10) {
                    inputMobile.setError("Invalid Mobile Number");
                    inputMobile.requestFocus();
                    return;
                } else {
                    Toast.makeText(com.example.tatatoyo.MainActivity.this, inputMobile.getText().toString().trim(), Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(com.example.tatatoyo.MainActivity.this, OTP.class);
                    String s = inputMobile.getText().toString().trim();
                    intent.putExtra("mob", s);
                    startActivity(intent);
                    finish();
                }
            }
        });


    }

    private void isUserRegistered() {
        String uid = "gjfhgkd454dsfvk";
        db.collection("Users").document(uid).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if(task.getResult().exists()){

                }
                else{
                    mAuth.signOut();
                    Intent intent = new Intent(MainActivity.this, MainActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onStart() {
        super.onStart();

        if(!haveNetworkConnection())
        {
            showDialog();
        }
    }

    // check network
    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean haveNetworkConnection() {
        boolean haveConnectedWifi = false;
        boolean haveConnectedMobile = false;

        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] netInfo = cm.getAllNetworkInfo();
        for (NetworkInfo ni : netInfo) {
            if (ni.getTypeName().equalsIgnoreCase("WIFI"))
                if (ni.isConnected())
                    haveConnectedWifi = true;
            if (ni.getTypeName().equalsIgnoreCase("MOBILE"))
                if (ni.isConnected())
                    haveConnectedMobile = true;
        }
        return haveConnectedWifi || haveConnectedMobile;
    }

    // internet check dialog
    private void showDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Network Unavailable....\nConnect to Internet And Restart.")
                .setCancelable(false)
                .setNegativeButton("Quit", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}