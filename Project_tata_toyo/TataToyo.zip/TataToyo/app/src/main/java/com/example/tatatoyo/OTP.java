package com.example.tatatoyo;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class OTP extends AppCompatActivity {

    // otp
    private EditText input_Code_1, input_Code_2, input_Code_3, input_Code_4, input_Code_5, input_Code_6;
    private FirebaseAuth mAuth;
    private  String mobile_number , Code , otp_id;
    private String user_id;
    private FirebaseFirestore db;
    private PhoneAuthProvider.ForceResendingToken mtoken;
    private long mLastClickTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_o_t_p);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mAuth = FirebaseAuth.getInstance();
        mobile_number = "+91"+ getIntent().getStringExtra("mob");


        ProgressBar progressBar = findViewById(R.id.bar);
        progressBar.setVisibility(View.VISIBLE);
        // got access
        input_Code_1 = findViewById(R.id.code_one);
        input_Code_2 = findViewById(R.id.code_two);
        input_Code_3 = findViewById(R.id.code_three);
        input_Code_4 = findViewById(R.id.code_four);
        input_Code_5 = findViewById(R.id.code_five);
        input_Code_6 = findViewById(R.id.code_six);

        setupOtpInputs();

        // string code

        Button button = findViewById(R.id.button);
        button.setVisibility(View.INVISIBLE);

        //phone callback
        PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks
                = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                signInWithPhoneAuthCredential(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(@NonNull FirebaseException e) {

                Toast.makeText(getApplicationContext(), "Verification Failed Try Again", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(com.example.tatatoyo.OTP.this , com.example.tatatoyo.MainActivity.class);
                startActivity(intent);
                finish();
                e.printStackTrace();
            }

            @Override
            public void onCodeSent(@NonNull String s, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {

                progressBar.setVisibility(View.INVISIBLE);
                button.setVisibility(View.VISIBLE);
                otp_id = s;
                mtoken = forceResendingToken;
            }

            @Override
            public void onCodeAutoRetrievalTimeOut(@NonNull String s) {
                
            }
        };

        validate_otp(mCallbacks); //Validate otp;


        // going inside the registration screen
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                Code = input_Code_1.getText().toString()+ input_Code_2.getText().toString() +input_Code_3.getText().toString().trim()+input_Code_4.getText().toString()+input_Code_5.getText().toString()+input_Code_6.getText().toString();
                if(Code.isEmpty() || Code.length() < 6)
                {
                    Toast.makeText(getApplicationContext() , "Invalid OTP" , Toast.LENGTH_SHORT).show();
                }
                else {
                    verify_code(Code);

                }
            }
        });
    }


    //set phone auth options
    private void validate_otp(PhoneAuthProvider.OnVerificationStateChangedCallbacks Callbacks) {

        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(mobile_number)       // Phone number to verify
                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                        .setActivity(this)                 // Activity (for callback binding)
                        .setCallbacks(Callbacks)          // OnVerificationStateChangedCallbacks
                        .build();

        PhoneAuthProvider.verifyPhoneNumber(options);

    }

    private void resendVerificationCode(PhoneAuthProvider.OnVerificationStateChangedCallbacks Callbacks) {
        PhoneAuthOptions options =
                PhoneAuthOptions.newBuilder(mAuth)
                        .setPhoneNumber(mobile_number)
                        .setTimeout(60L, TimeUnit.SECONDS)
                        .setActivity(this)
                        .setCallbacks(Callbacks)
                        .setForceResendingToken(mtoken)
                        .build();

        PhoneAuthProvider.verifyPhoneNumber(options);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {

//                            startActivity(new Intent(OTP.this, Registration.class));
                            check_login_firstTime();

                        } else {

                            Toast.makeText(getApplicationContext(), "Failed to SignIn", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(com.example.tatatoyo.OTP.this , com.example.tatatoyo.MainActivity.class);
                            startActivity(intent);
                            finish();

                        }
                    }
                });
    }

    private void verify_code(String user_code) {

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(otp_id, user_code);
        signInWithPhoneAuthCredential(credential);

    }

    // moving cursor automatically
    private void setupOtpInputs(){
        input_Code_1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!charSequence.toString().trim().isEmpty()){
                    input_Code_2.requestFocus();

                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        input_Code_2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!charSequence.toString().trim().isEmpty()){
                    input_Code_3.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        input_Code_3.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!charSequence.toString().trim().isEmpty()){
                    input_Code_4.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        input_Code_4.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!charSequence.toString().trim().isEmpty()){
                    input_Code_5.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        input_Code_5.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!charSequence.toString().trim().isEmpty()){
                    input_Code_6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        input_Code_6.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(!charSequence.toString().trim().isEmpty()){
                    input_Code_6.requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }


    private void check_login_firstTime() {
        FirebaseUser firebaseUser = mAuth.getCurrentUser();


        if (firebaseUser != null) {
            user_id = firebaseUser.getUid();
        }

        db = FirebaseFirestore.getInstance();
        final DocumentReference userRef = db.collection("Users").document(user_id);

        userRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();

                    if (document != null && document.exists()) {

                        startActivity(new Intent(com.example.tatatoyo.OTP.this, BottomNav.class));

                    } else {
                        startActivity(new Intent(com.example.tatatoyo.OTP.this, Registration.class));


                    }
                    finish();

                } else {

                    Log.d("Failed with: ", Objects.requireNonNull(task.getException()).toString());
                }

            }
        });

    }
}