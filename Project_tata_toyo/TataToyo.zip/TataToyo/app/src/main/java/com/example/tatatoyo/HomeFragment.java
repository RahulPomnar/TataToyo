package com.example.tatatoyo;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Objects;


public class HomeFragment extends Fragment {

    public static TextView textView;
    private long mLastClickTime = 0;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    public static TextView L1, L3, L5, L25, L210, L13;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View rootview = inflater.inflate(R.layout.fragment_home, container, false);

        // creating firestore instances
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        ImageView scanner = rootview.findViewById(R.id.scanner_top);
        textView = rootview.findViewById(R.id.points_number);

        //getting all the cards
        L1 = rootview.findViewById(R.id.one_litre_boxes);
        L3 = rootview.findViewById(R.id.two_litre_boxes);
        L5 = rootview.findViewById(R.id.five_litre_boxes);
        L25 = rootview.findViewById(R.id.twentyfive_litre_boxes);
        L210 = rootview.findViewById(R.id.twohundreten_litre_boxes);
        L13 = rootview.findViewById(R.id.thirteen_litre_boxes);

        set_points();
        scanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                // passing current points
                Intent intent = new Intent(view.getContext(), ScannerActivity.class);
                intent.putExtra("p", textView.getText().toString().trim());
                startActivity(intent);
            }
        });

        ImageView Log_out = rootview.findViewById(R.id.logout);

        Log_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDialog();
            }
        });

        String[] data = {"1L","3L", "5L", "25L","210L" , "1:3L"};

        return rootview;
    }


    private void set_points(){
        String firebase_user = mAuth.getUid();

        //if no network
        if(firebase_user == null){
            Toast.makeText(getContext(), "poor network", Toast.LENGTH_LONG).show();
            return;
        }

        db.collection("Users").document(firebase_user).get()
                .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                    @Override
                    public void onSuccess(DocumentSnapshot documentSnapshot) {
                            textView.setText(documentSnapshot.getString("points"));
                            L1.setText(documentSnapshot.getString("l1"));
                            L3.setText(documentSnapshot.getString("l3"));
                            L5.setText(documentSnapshot.getString("l5"));
                            L25.setText(documentSnapshot.getString("l25"));
                            L210.setText(documentSnapshot.getString("l21"));
                            L13.setText(documentSnapshot.getString("l13"));
                    }
                });
    }

    private void showDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(getContext()));
        builder.setMessage("Are you sure you want to logout?")
                .setCancelable(false)
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        FirebaseAuth.getInstance().signOut();
                        Intent intent = new Intent(getActivity(),
                                MainActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("NO", null);
        AlertDialog alert = builder.create();
        alert.show();
    }

}
