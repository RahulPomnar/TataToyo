package com.example.tatatoyo;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class Registration extends AppCompatActivity {

    private EditText Shop_Name , Owner_Name , Shop_Address , City , Pin_Code , State;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private String Userid;
    private  long mLastClickTime = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        Shop_Name = findViewById(R.id.shopName);
        Owner_Name = findViewById(R.id.ownerName);
        Shop_Address = findViewById(R.id.shopAddress);
        City = findViewById(R.id.city);
        Pin_Code = findViewById(R.id.pinCode);
        State = findViewById(R.id.state);




        Button login = findViewById(R.id.button);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();

                Register_User();
            }
        });
    }

    private  void Register_User(){
        final String Name = Shop_Name.getText().toString().trim();
        final  String address = Shop_Address.getText().toString().trim();
        final String owner = Owner_Name.getText().toString().trim();
        final String city = City.getText().toString().trim();
        final String pin = Pin_Code.getText().toString().trim();
        final String state = State.getText().toString().trim();

        if (Name.isEmpty()) {
            Shop_Name.setError("Field is required");
            Shop_Name.requestFocus();
            return;
        }

        if (address.isEmpty()) {
            Shop_Address.setError("Field is required");
            Shop_Address.requestFocus();
            return;
        }

        if (owner.isEmpty()) {
            Owner_Name.setError("Field is required");
            Owner_Name.requestFocus();
            return;
        }
        if (city.isEmpty()) {
            City.setError("Field is required");
            City.requestFocus();
            return;
        }

        if (pin.isEmpty()) {
            Pin_Code.setError("Field is required");
            Pin_Code.requestFocus();
            return;
        }

        if (state.isEmpty()) {
            State.setError("Field is required");
            State.requestFocus();
            return;
        }



        FirebaseUser Firebase_User = mAuth.getCurrentUser();

        if (Firebase_User != null) {
            Userid = Firebase_User.getUid();
        }

        assert Firebase_User != null;
        String mob = Firebase_User.getPhoneNumber();

        com.example.tatatoyo.User user = new com.example.tatatoyo.User(Name , owner ,address , city ,pin ,state ,mob);

        db.collection("Users").document(Userid).set(user)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isComplete()) {
                            Toast.makeText(com.example.tatatoyo.Registration.this, "Registered Successfully", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(com.example.tatatoyo.Registration.this, BottomNav.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                            startActivity(intent);
                            finish();

                        } else {
                            Toast.makeText(com.example.tatatoyo.Registration.this, "Failed to Register try again", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(com.example.tatatoyo.Registration.this, com.example.tatatoyo.MainActivity.class);
                            startActivity(intent);


                        }
                    }
                });
    }
}